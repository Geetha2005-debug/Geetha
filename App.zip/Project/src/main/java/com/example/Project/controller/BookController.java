
package com.example.Project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Project.model.Books;
import com.example.Project.repository.BookRepository;

@RestController
@RequestMapping("/book")
@CrossOrigin(origins = "http://localhost:5173")
public class BookController 
{
    
    
    @Autowired
    BookRepository br;

    @PostMapping("/addbook")
    ResponseEntity<?> addbook(@RequestBody Books b)
    {
        Books result=this.br.findByTitle(b.getTitle());
        if(result !=null)
        {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("the username is already exist");
        }
         this.br.save(b);
         return ResponseEntity.status(HttpStatus.CREATED).body("book  added successfully");
    }

    @PostMapping
    List<Books> viewAll()
    {
        List<Books> result=this.br.findAll();
        return result;
    }

    @PostMapping("/authorform/{name}")
    List<Books> viewByAuthor(@PathVariable String name)
    {
        return this.br.findByAuthor(name);
        
    }
}
