import axios from "axios"
import { useState } from "react"

function AddBook() {
  const [form, setform] = useState({
    title: "",
    author: "",
    description: ""
  })

  const changedata = (e) => {
    setform({ ...form, [e.target.name]: e.target.value })
  }

  const submitform = async (e) => {
    e.preventDefault()
    try {
      const response = await axios.post("http://localhost:8080/addbook", form)
      alert(response.data)
    } catch (error) {
      console.error(error)
      alert("Failed to add book")
    }
  }

  return (
    <>
      <h1>Add a book</h1>
      <form onSubmit={submitform}>
        <input onChange={changedata} type="text" name="title" placeholder="Enter title" />
        <input onChange={changedata} type="text" name="author" placeholder="Enter author name" />
        <input onChange={changedata} type="text" name="description" placeholder="Write about book..." />
        <button type="submit">Add Book</button>
      </form>
    </>
  )
}

export default AddBook
