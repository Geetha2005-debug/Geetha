import axios from "axios"
import { useState } from "react"

function AuthorBook() {
  const [author, setAuthor] = useState("")
  const [result, setResult] = useState([])

  const submitform = async (e) => {
    e.preventDefault()
    try {
      const response = await axios.get(`http://localhost:8080/book/author/${author}`)
      setResult(response.data)
    } catch (error) {
      console.error(error)
      alert("Error fetching books")
    }
  }

  const changedata = (e) => {
    setAuthor(e.target.value)
  }

  return (
    <>
      <h1>Search Books by Author</h1>
      <form onSubmit={submitform}>
        <input onChange={changedata} type="text" name="author" placeholder="Enter author name" />
        <button type="submit">Search</button>
      </form>
      <ul>
        {result.map((x, index) => (
          <li key={index}>
            {x.title} - {x.author} - {x.description}
          </li>
        ))}
      </ul>
    </>
  )
}

export default AuthorBook
