import axios from "axios"
import { useState } from "react"
import { Link } from "react-router-dom"

function Library() {
  const [result, setResult] = useState([])

  const viewallbooks = async (e) => {
    e.preventDefault()
    try {
      const response = await axios.get("http://localhost:8080/book")
      setResult(response.data)
    } catch (error) {
      console.error(error)
      alert("Error fetching books")
    }
  }

  return (
    <>
      <h1>You are in Library...</h1>
      <Link to="/abook">Add Book</Link><br />
      <button onClick={viewallbooks}>View All Books</button><br />
      <Link to="/vauthorbooks">View Books by Author</Link><br />
      <ul>
        {result.map((x, index) => (
          <li key={index}>
            {x.title} {x.author} {x.description}
          </li>
        ))}
      </ul>
    </>
  )
}

export default Library
