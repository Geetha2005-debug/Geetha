import { BrowserRouter, Route, Routes } from "react-router-dom"
import Home from "./Home"
import Register from "./Register"
import Login from "./Login"
import Admin from "./Admin"
import Library from "./Library"
import AuthorBook from "./Books/AuthorBook"

function App()
{
  return(
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/reg" element={<Register/>}/>
          <Route path="/log" element={<Login/>}/>
          <Route path="/admin" element={<Admin/>}/>
          <Route path="/library" element={<Library/>}/>
          <Route path="/abook" element={<AddBook/>}/>
          <Route path="/vauthorbooks" element={<AuthorBook/>}/>
        </Routes>
      </BrowserRouter>
    </>
  )
}
export default App